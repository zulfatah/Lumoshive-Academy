### Warna Tulisan Bold #414141
### Warna Tulisan Regular #5E5B5B